<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Gringo
 * @since Gringo 1.0
 */
get_header(); ?>
<style type="text/css">
.calc-short {
	background-color: #fafafa;
	-webkit-box-shadow: 0 4px 6px rgba(190,132,0,.3);
    box-shadow: 0 4px 6px rgba(190,132,0,.3);
}
</style>
<section class="section pt-5">
    <div class="container single-container">

		<?php 
		/* Start the Loop */
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content/content', 'single' );

		endwhile; // End of the loop.
		?>
	</div>
</section>

<section class="section features-section">
    <div class="container">
        <?php get_template_part( 'template-parts/features' ); ?>
    </div>
</section>

<?php get_footer();