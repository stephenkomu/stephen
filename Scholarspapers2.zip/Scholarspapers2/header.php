<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @package WordPress
 * @subpackage Gringo
 * @since Gringo 1.0
 */
?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?> class="no-js no-svg" style=" margin: 0 !important; ">

    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="profile" href="https://gmpg.org/xfn/11">
        <link rel="stylesheet" href="<?php echo get_theme_file_uri('/pages.css'); ?>">
        <link rel="stylesheet" href="<?php echo get_theme_file_uri('/assets/fontawesome/css/all.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo get_theme_file_uri('/assets/bootstrap/css/bootstrap.min.css'); ?>">
        <?php wp_head(); ?>

            <script type="application/ld+json">
                { "@context":"https:\/\/schema.org", "@type":"WebSite", "@id":"#website", "url":"
                <?php bloginfo( 'url' ); ?>", "name":"
                    <?php bloginfo( 'name' ); ?>", "alternateName": "
                        <?php bloginfo( 'name' ); ?>", "aggregateRating": { "@type": "AggregateRating", "ratingValue": "5", "reviewCount": "2067", "bestRating": "5", "worstRating": "3.4" } }
            </script>
            <script>
                window.dataLayer = window.dataLayer || [];

                function gtag() {
                    dataLayer.push(arguments);
                }
                gtag('js', new Date());

                gtag('config', 'UA-124430324-5');
            </script>

            <script src="<?php echo get_theme_file_uri( '/assets/js/jquery.min-3.2.1.js' ) ?>"></script>
            <script src="<?php echo get_theme_file_uri( '/assets/js/nav-bar.js' ) ?>"></script>

    </head>

    <body <?php body_class(); ?>>
    <header class="header fixed cookies" id="header" style="position: relative;">
        <div class="component-wrap header-wrap flex flex-ai-c flex-jc-spBet">
            <div class="header-item logo-item">
                <a href="/" class="header-logo">
                    <img src="/wp-content/themes/expert-ux/images/svg/logo.svg" alt="">
                </a>
                <div class="mobile-nav" id="mobile_nav">
                    <div class="slicknav_menu"><a href="#" aria-haspopup="true" tabindex="0" class="slicknav_btn slicknav_collapsed" style="outline: none;"><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a>
                        <ul class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                            <?php
                                wp_nav_menu( array(
                                    'theme_location' => 'header_main_nav',
                                    'menu_class'     => 'primary-menu',
                                    'items_wrap'     => '%3$s',
                                    'container' => ''
                                ));
                            ?>
                            <li class="menu-item mobile-visible">
                                <div class="btn-order"><a href="/order" class="cta-1" tabindex="-1">New Order</a></div>
                            </li>
                            <li class="menu-item mobile-visible"><a href="/login" class="log-btn" role="menuitem" tabindex="-1"><i class="fas fa-user"></i> Login to Account</a></li>
                            <li class="menu-item call-line mobile-visible"><img src="/wp-content/themes/expert-ux/images/phone.png"> <a href="tel:+1(978) 822-0999" class="cta-1 call-btn" role="menuitem" tabindex="-1">Call</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="header-item">
                <span class="phone-item">
                </span>

                <div class="nav-menu-item ">
                    <ul id="menu-nav-menu" class="menu">
                            <?php
                                wp_nav_menu( array(
                                    'theme_location' => 'header_main_nav',
                                    'menu_class'     => 'primary-footer',
                                    'items_wrap'     => '%3$s',
                                    'container' => ''
                                ));
                            ?>
                        <li class="menu-item mobile-visible">
                            <div class="btn-order"><a href="/order" class="cta-1">New Order</a></div>
                        </li>
                        <li class="menu-item mobile-visible"><a href="/login" class="log-btn"><i class="fas fa-user"></i> Login to Account</a></li>
                        <li class="menu-item call-line mobile-visible"><img src="/wp-content/themes/expert-ux/images/phone.png"> <a href="tel:+1(978) 822-0999" class="cta-1 call-btn">Call</a></li>
                    </ul>
                </div>

            </div>

            <div class="header-item btn-item">
                <div class="btn-order">
                    <a href="/order" class="cta-1"><span>New Order</span></a>
                </div>
                <div class="btn-login">
                    <div data-crm-widget="loginTooltip" data-params="{&quot;theme&quot;:&quot;builder&quot;, &quot;template_name&quot; : &quot;login_tooltip&quot;}">
                        <div data-crm="loader" style="display: none;"></div>
                        <div style="display: block;">
                            <link href="/wp-content/special/proxy_order.php?r=/assets/css-compress/afc6f4a31037dd5260f90e5c0f6cb7a7.css?v=1563192964" rel="stylesheet">
                            <div id="of-widgets-login-tooltip">
                                <a href="/login" class="of-widgets-open-tooltip" id="cw-open-login-tooltip">
                                    Login                    
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </header>