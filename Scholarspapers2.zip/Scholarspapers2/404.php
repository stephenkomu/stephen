<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Gringo
 * @since Gringo 1.0
 */
get_header(); ?>

<section class="section seo-section section-404">
    <div class="container">
        <h1 class="text-center">Oops, we could not find the requested page. Sorry!</h1>
        <div class="row">
        
            <div class="col-sm-12 col-lg-6 col-md-6">

				<div class="search-form">
					<?php get_template_part('searchform'); ?>
				</div>

				<?php get_template_part('404menu'); ?>

			</div>
			
            <div class="col-sm-12 col-lg-6 col-md-6">
                <img src="<?php echo get_theme_file_uri( '/assets/images/404.gif' ) ?>" alt="">
            </div>
        </div>
        
    </div>
</section>

<?php get_footer();
