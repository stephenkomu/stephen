$(document).ready(function(){

    $("#mobile_nav").click(function(){
        $(".slicknav_nav.slicknav_hidden").toggle();
    })
})