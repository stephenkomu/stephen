$(document).ready(function(){

    var ship_width=$("#ship").width();


    function anchor(width){

        if($(window).scrollTop()>=$("#ship").offset().top){
            if($(window).scrollTop() < ( $(".calculator-wrapper").innerHeight() + $(".calculator-wrapper").offset().top )){
                $("#ship").removeClass("fixed");
            }else if($(window).scrollTop() > ( $(".calculator-wrapper").innerHeight() + $(".calculator-wrapper").offset().top )){ 
                $("#ship").addClass("fixed");
                $("#ship").css('width',width + 'px');           
            }

            if($(window).scrollTop()>)
        }else{
            $("#ship").removeClass("fixed");
        }

    }

    setInterval(anchor(ship_width),100);

})