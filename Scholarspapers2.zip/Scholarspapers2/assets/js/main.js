function Lt() {
	document.querySelector(".nav").addEventListener("click", function(t) {
		window.innerWidth <= 1215 &&
			(function t(e, n, r) {
				return (
					e.parentNode !== document.documentElement &&
					!e.parentNode.matches(r) &&
					(!!e.parentNode.matches(n) || void t(e.parentNode, n))
				);
			})(t.target, ".nav__item--dropdown") &&
			t.target.parentNode.querySelector("ul").classList.toggle("active");
	});
}

document.addEventListener("DOMContentLoaded", function() {
	var t = document.querySelector(".js-hamburger");
	if (!t) return !1;
	var e = document.querySelector(".header__nav");
	e.querySelector("ul"),
		"hidden" === getComputedStyle(e).visibility &&
			e.setAttribute("aria-hidden", !0);
	var n = function() {
			t.classList.toggle("is-active"),
				e.classList.toggle("is-active"),
				document.documentElement.classList.toggle("no-scroll"),
				document.body.classList.toggle("no-scroll"),
				e.classList.contains("is-active")
					? (e.setAttribute("aria-hidden", !1),
					  t.setAttribute("aria-expanded", !0),
					  (e.style.height = "".concat(window.innerHeight, "px")),
					  e.addEventListener("click", r))
					: (e.setAttribute("aria-hidden", !0),
					  t.setAttribute("aria-expanded", !1),
					  (e.style.height = ""),
					  e.removeEventListener("click", r));
		},
		r = function(t) {
			return t.target === e && n();
		};
	t.addEventListener("click", n);

	document.querySelector(".nav") && Lt();
});
