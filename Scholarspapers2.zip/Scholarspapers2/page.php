<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Gringo
 * @since Gringo 1.0
 */
get_header(); ?>

<?php //get_template_part( 'template-parts/page-hero' ); ?>
<div class="container page-container">
    <div class="row">
        <div class="col-sm-12 col-lg-8 col-md-12">
            <?php while ( have_posts() ) : the_post(); ?>
                <section class="section seo-section">
                    <div>
                        <div class="seo-section__text">
                            <h1 class="page-title"><?php echo the_title(); ?></h1>
                            <?php the_content(); ?>
                        </div>
                        <div class="pay-buttons seo-section__buttons">
                            <a href="/order" class="btn btn--primary pay-buttons__item" rel="nofollow">Continue to order</a>
                            <a href="/inquiry" class="btn btn--alternate pay-buttons__item" rel="nofollow">Get a quote</a>
                        </div>
                    </div>
                </section>
            <?php endwhile; ?>
        </div>
        <div class="col-sm-12 col-lg-4 col-md-12">
            <?php get_template_part( 'template-parts/site-calc' ); ?>
        </div>
    </div>
</div>


<section class="section features-section">
    <div class="container">
        <h2 class="title title--md">What you get from our essay writing service</h2>
        <?php get_template_part( 'template-parts/features' ); ?>
    </div>
</section>

<?php //get_template_part( 'template-parts/cta/cta', 'calculator' ); ?>

<?php get_footer();
