<section class="section steps-section">
    <div class="container">

        <div data-observed-bg="" class="steps steps--cheap-essays load-bg">
            <h2 class="title title--md">How to get a similar high-quality essay</h2>
            <p>The process of ordering your paper from us is as easy as ABC.</p>
            <div class="steps__list">
                <div class="steps__item">
                    <span>1</span>
                    <p>Hit the “Order my paper” button</p>
                </div>
                <div class="steps__item">
                    <span>2</span>
                    <p>Attach your instructions</p>
                </div>
                <div class="steps__item">
                    <span>3</span>
                    <p>Estimate your deadline</p>
                </div>
                <div class="steps__item">
                    <span>4</span>
                    <p>Wait for the paper to be done</p>
                </div>
            </div>
            <div class="steps__btn-box">
                <a href="/order" rel="nofollow" class="steps__btn btn btn--primary">Order my paper</a>
            </div>
        </div>
    </div>
</section>