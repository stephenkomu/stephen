<div class="features-section__row">
    <div class="features-section__item">
        <div class="features-block">
            <div class="features-block__title">Basic features</div>
            <ul class="features-block__descr">
                <li>Free title page and bibliography</li>
                <li>Unlimited revisions</li>
                <li>Plagiarism-free guarantee</li>
                <li>Money-back guarantee</li>
                <li>24/7 support</li>
            </ul>
        </div>
    </div>
    <div class="features-section__item">
        <div class="features-block">
            <div class="features-block__title">On-demand options</div>
            <ul class="features-block__descr features-block__descr--yellow-check">
                <li>Writer’s samples</li>
                <li>Part-by-part delivery</li>
                <li>Overnight delivery</li>
                <li>Copies of used sources</li>
                <li>Expert Proofreading</li>
            </ul>
        </div>
    </div>
    <div class="features-section__item">
        <div class="features-block features-block--grey">
            <div class="features-block__title">Paper format</div>
            <ul class="features-block__descr">
                <li>275 words per page</li>
                <li>12 pt Arial/Times New Roman</li>
                <li>Double line spacing</li>
                <li>Any citation style (APA, MLA, Chicago/Turabian, Harvard)</li>
            </ul>
        </div>
    </div>
</div>