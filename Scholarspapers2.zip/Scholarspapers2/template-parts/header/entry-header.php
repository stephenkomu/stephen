<div class="text-center">
	<?php the_title( '<h1 class="text-center">', '</h1>' ); ?>	
</div>
