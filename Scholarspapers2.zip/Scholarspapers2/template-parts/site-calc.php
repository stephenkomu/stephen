<div class="simple-calculator__outer">
    <div class="section__title">Calculate the price of your paper</div>
    <div data-crm-widget="simplePriceCalc" data-params="{&quot;theme&quot;:&quot;raw&quot;,&quot;template&quot;:&quot;<div class=\&quot;simple-calc row\&quot;>\n    <div class=\&quot;col-sm-12\&quot;><div class=\&quot;simple-calc__field\&quot;>{type_of_work}<\/div><\/div>\n    <div class=\&quot;col-sm-12\&quot;><div class=\&quot;simple-calc__field\&quot;>{level_work}<\/div><\/div>\n    <div class=\&quot;col-sm-12\&quot;><div class=\&quot;simple-calc__field\&quot;>{urgency}<\/div><\/div>\n    <div class=\&quot;col-sm-12\&quot;><div class=\&quot;simple-calc__field\&quot;>{number_page}<\/div><\/div>\n<\/div>\n\n<div class=\&quot;field-price\&quot;>{price}<\/div>\n<div class=\&quot;field-submit\&quot;>{button}<\/div>\n&quot;,&quot;pdd&quot;:{&quot;type_of_work&quot;:20,&quot;level_work&quot;:2,&quot;urgency&quot;:11,&quot;number_page&quot;:1}}">
        <div data-crm="loader" style="display: none;"></div>
        <div style="display: block;">

            <form method="get" action="/order" data-calculator-form>
                <div class="simple-calc row">
                    <div class="col-sm-12">
                        <div class="simple-calc__field">
                            <select name="paperTypeId" class="calc-select f_sz_400 validate[required]" arial-label="Type of paper needed" data-academic-level-select="">

                            </select>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="simple-calc__field">
                            <select id="calculator-level_work" name="academicLevelId" class="calc-select academic-level" arial-label="List of academic level" data-academic-level-select-mobile="">
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="simple-calc__field">
                            <select id="calculator-urgency" name="deadlineId" class="calc-select" arial-label="List of deadline" data-deadline-static="">

                            </select>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="new-line-item calc-pages pages-control">
                            <div class="pages-control__head">
                                <label>Pages</label>
                                <span class="pageskol-title">
                                                (<span data-words-qty="">550 words</span>)
                                </span>
                            </div>
                            <div class="form-item form-item--field">
                                <div class="styled-pages pageskol">
                                    <input class="calc-input styled-pages-input" type="text" name="pages" arial-label="quantity of pages" data-pages-input="" value="2">
                                    <div class="styled-pages-button">
                                        <button class="increase buttonspin pageskol-right" type="button" aria-label="increase" data-plus-button=""></button>
                                        <button class="decrease buttonspin pageskol-left" type="button" aria-label="decrease" data-minus-button=""></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="new-line order-result order-m-group order-m-group--price">
                    <p class="total-price">
                        <span class="font-bold total-price-value" data-total-price=""><span>$</span>22</span>
                    </p>
                </div>
                <div class="new-line order-submit-line order-m-group order-m-group--submit">
                    <input class="btn btn--primary" type="submit" data-submit-button="" value="Continue to order">
                </div>
            </form>

        </div>
    </div>
</div>

<div class="bg-white text-dark shadow border p-4 rounded mb-4">
    <h2 class="h5">Give yourself the academic edge <b>today</b></h2>
    <p>Each order includes</p>
    <ul class="list-unstyled">
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->On-time delivery or your money back</li>
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->A fully qualified writer in your subject</li>
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->In-depth proofreading by our Quality Control Team</li>
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->100% confidentiality, the work is never re-sold or published</li>
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->Standard 7-day amendment period</li>
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->A paper written to the standard ordered</li>
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->A detailed plagiarism report</li>
        <li class="my-2">
            <svg class="svg-inline--fa fa-check fa-w-16 mr-2 text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path>
            </svg>
            <!-- <i class="fas fa-check mr-2 text-success"></i> -->A comprehensive quality report</li>
    </ul>
    <a class="btn bg-warning" href="/services"><b>Find out more</b> about our Essay <br>Writing Service</a>
</div>