<div class="mobile-navbar">
	<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"> 
		<img src="/static/assets/images/logo-optimized.svg" height="50" width="280" class="logo" alt="<?php bloginfo( 'name' ); ?> logo"> 
	</a>
</div>
<nav>
	<button class="mobile-nav-toggle"> <span class="hamburger-icon"></span> </button>
	<div class="mobile-nav">
		<div class="mobile-nav__header"> 
			<img src="/static/assets/images/logo-icon-original.svg" height="40" width="50" class="logo">
		</div>
		<div class="mobile-nav__body">
			<div class="mobile-nav__panels-container active-level1">
				<div class="mobile-nav__panel mobile-nav__panel--level1 overlap">
					<ul class="mobile-nav__list">
						<?php
							wp_nav_menu( array(
								'theme_location' => 'mobile-nav',
								'menu_class'     => 'main-menu',
								'items_wrap'     => '%3$s',
								'add_li_class' 		=> 'mobile-nav__item',
								'container' => ''
							));
						?>
						<li class="mobile-nav__item menu-item"> 
							<a class="mobile-nav__link " href="<?php echo esc_url( home_url( '/dashboard' ) ); ?>"> My Account </a>
						</li>
					</ul>
					<ul class="mobile-nav__list">
						<li class="mobile-nav__item menu-item mt-3"> 
							<a class="btn btn--orange d-block w-75 m-auto" href="<?php echo esc_url( home_url( '/order' ) ); ?>"> Order Now</a>
						</li>
						<li class="mobile-nav__item menu-item mt-3"> 
							<a class="btn btn--outline d-block w-75 m-auto" href="<?php echo esc_url( home_url( '/inquiry' ) ); ?>"> Get Free Quote</a>
						</li>
					</ul>

					<a href="<?php echo esc_url( home_url( '/?s' ) ); ?>" class="search-button-mobile fa fa-search hidden-lg-up"></a>

				</div>
			</div>
		</div>
	</div>
</nav>
