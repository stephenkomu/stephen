<nav class="nav main-nav">
	<div class="container">
		<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<img src="/static/assets/images/logo-optimized.svg" height="50" width="280" class="logo" alt="<?php bloginfo( 'name' ); ?>"> 
		</a>
		
		<a href="<?php echo esc_url( home_url( '/order' ) ); ?>" title="Order Now" class="btn btn--orange btn--small btn--upload" onclick="ga('send', 'event', 'Homepage', 'Order Now', 'Place an Order');">Order Now</a>
	</div>
</nav>