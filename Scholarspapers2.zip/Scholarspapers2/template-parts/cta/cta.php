<section class="cta">
    <div class="container">
        <div class="cta__content">
            <div class="cta__text">
                Order from us and get better grades. We are the service you have been looking for.
            </div>
            <div class="cta__actions">
                <a href="<?php echo esc_url( home_url( '/order' ) ); ?>" class="btn btn--primary">Order essay</a>
            </div>
        </div>
    </div>
</section>