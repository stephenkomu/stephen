<section class="section pay-section">
    <div class="container">
        <h2 class="title title--md">
            Calculate the price of your order
        </h2>
        <div class="pay-section__main">
            <div class="pay-section__calc">
                <div class="uvocalc--wrapper">
                    <div class="uvocalc">
                        <div data-calc-mini class="uvocalc--container">
                            <form name="uvocalculator" method="get" action="/" data-calculator-form style="display: block;">

                                <div class="uvocalc--type_of_paper">
                                    <label for="paperTypeId">Type of paper needed:</label>
                                    <div class="uvocalc--select">
                                        <select class="f_sz_400 validate[required]" name="paperTypeId" data-academic-level-select></select>
                                    </div>
                                </div>

                                <div class="uvocalc--pages">
                                    <div class="uvocalc--pages__title">
                                        <label for="pages">Pages:</label>
                                        <div class="uvocalc--pages__words" data-words-qty>550 words</div>
                                    </div>
                                    <div class="uvocalc--pages__buttons">
                                        <button type="button" title="Decrease" data-minus-button><span>−</span></button>
                                        <input name="pages" value="2" data-pages-input type="text">
                                        <button type="button" title="Increase" data-plus-button><span>+</span></button>
                                    </div>
                                </div>

                                <div class="uvocalc--field_tip uvocalc--field_tip_discount" style="display: none;" data-tip-discount>You will get a personal manager and a discount.</div>
                                <div class="uvocalc--field_tip uvocalc--field_tip_paper_type_id" data-notice></div>
                                <div class="uvocalc--academic_level">
                                    <label>Academic level:</label>
                                    <div class="uvocalc--academic_level_control visible-in-desktop" data-academic-level-control-upgrade>
                                    </div>
                                    <div class="visible-in-mobile">
                                        <div class="uvocalc--select">
                                            <select data-academic-level-select-mobile></select>
                                        </div>
                                    </div>
                                    <div class="uvocalc--academic_level_content" data-tariff-control-upgrade></div>
                                </div>

                                <div class="uvocalc--deadline">We'll send you the first draft for approval by <strong data-ext-time>September 11, 2018<span> at </span>10:52 AM</strong></div>
                                    <div class="uvocalc--total_price_container">
                                        <div class="uvocalc--total_price_title">Total price:</div>
                                        <div class="uvocalc--total_price" data-total-price><span>$</span>26</div>
                                    </div>
                                    <div class="uvocalc--submit__container">
                                        <input class="btn btn--primary" type="submit" title="Continue to Order" data-submit-button="" value="Continue to order" onclick="ga('send', 'event', 'Homepage', 'Continue to order', 'Calculate price for your order');">
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pay-section__price-factors">
                <div class="price-factors">
                    <div class="price-factors__title">
                        The price is based on these factors:
                    </div>
                    <div class="price-factors__items">
                        <div class="price-factors__item">
                            <div class="price-factors__item-img"></div>
                            <div class="price-factors__item-text">
                                Academic level
                            </div>
                        </div>
                        <div class="price-factors__item">
                            <div class="price-factors__item-img"></div>
                            <div class="price-factors__item-text">
                                Number of pages
                            </div>
                        </div>
                        <div class="price-factors__item">
                            <div class="price-factors__item-img"></div>
                            <div class="price-factors__item-text">
                                Urgency
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
