<?php
/**
 * The template part for displaying results in search pages
 *
 * @package WordPress
 * @subpackage Gringo
 * @since Gringo 1.0
 */
?>

<article class="page" id="post-<?php the_ID(); ?>">
	<?php the_title( sprintf( '<h4><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
	<em id="resultUrl">[Page] <?php echo esc_url( get_permalink() ); ?><br></em>
	<?php gringo_excerpt(); ?>
</article>