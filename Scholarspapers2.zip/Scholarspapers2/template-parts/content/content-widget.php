<div class="calc-short" data-calc-short>
    <form method="get" action="/order" data-calculator-form>
        <div class="order-m-group head-form">
            <div class="orderform-title">Order a unique copy of this paper</div>
        </div>
        <div class="new-line order-m-group">
            <label>Type of paper</label>
            <div class="form-item form-item--field">
                <div class="styled-select">
                    <select name="paperTypeId" class="calc-select" arial-label="Type of paper needed" data-academic-level-select="">
                        
                    </select>
                </div>
            </div>
        </div>
        <div class="new-line calc-academic-level order-m-group">
            <label>Academic level</label>
            <div class="form-item form-item--field">
                <div class="styled-select">
                    <select name="academicLevelId" class="calc-select academic-level" arial-label="List of academic level" data-academic-level-select-mobile="">
                    </select>
                </div>
            </div>
        </div>
        <div class="new-line new-line-flex">
            <div class="new-line-item calc-deadlines" data-tariff-control="">
                <label>Deadline</label>
                <div class="form-item form-item--field">
                    <div class="styled-select">
                        <select name="deadlineId" class="calc-select" arial-label="List of deadline" data-deadline-static="">
                            
                        </select>
                    </div>
                </div>
            </div>

            <div class="order-m-group order-m-group--pages">
                <div class="new-line-item calc-pages pages-control">
                    <div class="pages-control__head">
                        <label>Pages</label>
                        <span class="pageskol-title">
                            (<span data-words-qty="">550 words</span>)
                        </span>
                    </div>
                    <div class="form-item form-item--field">
                        <div class="styled-pages pageskol">
                            <input class="calc-input styled-pages-input" type="text" name="pages" arial-label="quantity of pages" data-pages-input="" value="2">
                            <div class="styled-pages-button">
                                <button class="increase buttonspin pageskol-right" type="button" aria-label="increase" data-plus-button=""></button>
                                <button class="decrease buttonspin pageskol-left" type="button" aria-label="decrease" data-minus-button=""></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="new-line order-result order-m-group order-m-group--price">
            <p class="total-price">
                Approximate price: <span class="font-bold total-price-value" data-total-price=""><span>$</span>22</span>
            </p>
        </div>
        <div class="new-line order-submit-line order-m-group order-m-group--submit">
            <input class="btn btn--primary" type="submit" data-submit-button="" value="Continue to order">
        </div>
    </form>
</div>