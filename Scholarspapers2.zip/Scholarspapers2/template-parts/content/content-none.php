<div class="error404">
	<div class="section-404">
		<h1 class="mb-5 text-center">Oops, your search did not match any documents. Sorry!</h1>
		<?php get_search_form(); ?>
	</div>
</div>