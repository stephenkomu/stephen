<section class="our-guarantees-section">
    <div class="container">
        <h1 class="our-guarantees-section__title">Our guarantees</h1>
        <p class="our-guarantees-section__descr">Delivering a high-quality product at a reasonable price is not enough anymore.
        <br> That’s why we have developed 5 beneficial guarantees that will make your experience with our service enjoyable, easy, and safe.</p>

        <div class="guarantees">
            <div class="guarantees__item">
                <h3>Money-back guarantee</h3>
                <p>You have to be 100% sure of the quality of your product to give a money-back guarantee. This describes us perfectly. Make sure that this guarantee is totally transparent.</p>
                <a href="/money-back-guarantee" class="btn">Read more</a>
            </div>
            <div class="guarantees__item">
                <h3>Zero-plagiarism guarantee</h3>
                <p>Each paper is composed from scratch, according to your instructions. It is then checked by our plagiarism-detection software. There is no gap where plagiarism could squeeze in.</p>
                <a href="/plagiarism-free-guarantee" class="btn">Read more</a>
            </div>
            <div class="guarantees__item">
                <h3>Free-revision policy</h3>
                <p>Thanks to our free revisions, there is no way for you to be unsatisfied. We will work on your paper until you are completely happy with the result.</p>
                <a href="/revisions-policy" class="btn">Read more</a>
            </div>
            <div class="guarantees__item">
                <h3>Privacy policy</h3>
                <p>Your email is safe, as we store it according to international data protection rules. Your bank details are secure, as we use only reliable payment systems.</p>
                <a href="/privacy-policy" class="btn">Read more</a>
            </div>
            <div class="guarantees__item">
                <h3>Fair-cooperation guarantee</h3>
                <p>By sending us your money, you buy the service we provide. Check out our terms and conditions if you prefer business talks to be laid out in official language.</p>
                <a href="/terms-conditions" class="btn">Read more</a>
            </div>
        </div>

    </div>
</section>