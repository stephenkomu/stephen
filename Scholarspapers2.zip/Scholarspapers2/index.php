<?php get_header(); ?>

	<main role="main" class="blog_post_container">
		<!-- section -->
		<section class="container">
			<div class="row">

				<div class="col-lg-8 col-md-12 col-sm-12">					
					<?php get_template_part('loop'); ?>

					<?php get_template_part('pagination'); ?>
				</div>
				<div class="col-lg-4 col-md-12 col-sm-12">
					<?php get_template_part( 'template-parts/site-calc' ); ?>
				</div>
			</div>

			

		</section>
		<!-- /section -->
	</main>

<?php get_footer(); ?>
