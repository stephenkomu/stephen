

<div class="no_post_menu"> 	
	<?php if ( has_nav_menu( 'header_services_links' ) ) : ?>
		<div class="footer-col">
            <ul>
                <?php
                    wp_nav_menu( array(
                        'theme_location' => 'header_services_links',
                        'menu_class'     => 'primary-menu',
                        'items_wrap'     => '%3$s',
                        'add_li_class' 	 => 'nav__item',
                        'container' => ''
                    ));
                ?>
            </ul>
		</div>
	<?php endif; ?>
</div>